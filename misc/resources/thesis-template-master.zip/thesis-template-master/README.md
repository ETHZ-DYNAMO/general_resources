# Thesis Template

The content of the thesis should be structured using the three commands `\frontmatter`, `\mainmatter`, and `\appendix`, which change the pagestyle and in particular the page numbering accordingly.

The template provides the `\TODO{...}` and `\REMARK{...}` commands to add annotations to the generated document.

The template provides the following theorem-like environments:
 - theorem, lemma, corollary, observation
 - definition, problem, assumption, example
 - claim, remark
 - proof

## Acknowledgement

Adapted from the template used in the Distributed Computing Group at ETH Zurich.
